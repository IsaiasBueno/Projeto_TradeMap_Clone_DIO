package com.isaiasbueno.projeto_trademap_clone_dio.projeto_trademap_clone_dio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoTrademapCloneDioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoTrademapCloneDioApplication.class, args);
	}

}
