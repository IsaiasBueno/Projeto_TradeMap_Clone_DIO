package com.isaiasbueno.projeto_trademap_clone_dio.projeto_trademap_clone_dio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoTrademapCloneDioApplicationTests {

	@Test
	void contextLoads() {
	}

}
